import fr.emse.simulator.world.Wall;

/** @author Charlotte Duruisseau, Dylan Feith */

//mettre un constructeur + modifier parse

public class Barrier extends Entity implements Wall {
	
	
}
