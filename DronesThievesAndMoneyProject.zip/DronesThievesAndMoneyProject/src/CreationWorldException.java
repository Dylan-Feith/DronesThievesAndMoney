
@SuppressWarnings("serial")
public class CreationWorldException extends Exception {
	
	public CreationWorldException() {
		System.out.println("Le fichier n'est pas valide. v�rifiez le nombre de lignes et de colonnes svp.");
	}
}
