import fr.emse.simulator.world.Occupant;

/** @author Charlotte Duruisseau, Dylan Feith */


public abstract class Entity implements Occupant {
	protected WorldCell cell;
}
